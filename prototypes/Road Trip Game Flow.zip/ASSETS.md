# Road Trip — Entry/Exit Flow · Asset & Interaction Reference

Everything in this mockup is drawn with **CSS + system emoji** — there are **no binary
image files** to hand off. That's deliberate: it stays inline, has zero external
dependencies, and wraps cleanly into Capacitor. This sheet lists every icon, color,
and drawn shape so you can swap emoji for real art later without hunting through code.

---

## Files
- `Road Trip - Entry Exit Flow.dc.html` — the source prototype.
- `support.js` — runtime it loads (do not edit).
- `Road Trip - Prototype (standalone).html` — single self-contained file, opens offline
  in any browser. Use this to demo / share.

---

## Palette (sunny daytime)
| Token        | Hex       | Use |
|--------------|-----------|-----|
| Sky          | `#6FD3F2` → `#BDEBFA` | top gradient, wipe into hub |
| Grass        | `#8FD98A` / `#6EC46A` | terrain |
| Farmland     | `#CFE38A` | mid terrain band |
| Desert       | `#E6C179` / `#D9B36A` | lower terrain band |
| Coast water  | `#6FC3E8` / `#5FB8E6` | top harbor + bottom coast |
| Panel cream  | `#FFF8EC` | all cards, pills, bubbles |
| Ink (text)   | `#1F3A5F` | primary text on light |
| Sub text     | `#5C7893` | secondary text |
| Sunshine     | `#FFD23F` / `#E8A200` | sun, road dashes, Medium tier, gold accents |
| Orange/Red   | `#FF6B4A` | Driver accent, Hard tier, RETRY, logo TRIP |
| Teal         | `#3FB6C7` | Navigator accent |
| Green        | `#2E9E4F` | Easy tier, unlock success |
| Purple       | `#7B61FF` | Mixtape accent |
| Locked grey  | `#8b93ad` / `#E4E9EE` | locked pins & pills |

Font: **Trebuchet MS** (system), bold weights throughout.

---

## Icons (emoji — replace with art later)
**Map / locations:** 🗽 New York (start) · 🏛️ D.C. · 🚜 Farmlands · 🌵 Desert ·
🎬 L.A. · 🌉 S.F. · 🚗 player car · 🌲🌾🌵 scenery.
**Right dock:** 👨 Dad = Driver · 👩 Mom = Navigator · 🚙 Dealership · 📻 radio.
**Games/UI:** 🥁 Driver/Tap Trip · 🧭 Navigator · 🔒 locked · 🔓 unlocked · ▶ play ·
🛣️ miles · 🎵 songs.

## Mixtape icon — drawn in CSS, changes with tuned era
Rendered in `mixtapeIcon(era)` (logic class), not emoji:
- **70s → 8-track**: brown chunky rectangle.
- **80s → cassette**: black rect with two white reels.
- **90s → CD**: rainbow conic-gradient disc with center hole.
- **00s → MP3 player**: white rounded rect, teal screen + click wheel.
Tap the radio dock to cycle the era; the icon updates live.

---

## The entry/exit system (the actual design)
- **One wipe transition** for every screen change (hub ⇄ mode, play, result). Colored
  panel slides up, labeled with a themed verb ("TUNING IN…", "STARTING ENGINE…").
  Reused everywhere so movement feels like one system.
- **Map = hub.** Tall vertical scroll; terrain shifts to sell distance. Cities unlock
  in place (greyed → bright), no separate menu.
- **Games on a fixed right dock** (Dad/Mom/Dealership/Mixtape) so the map stays
  browseable without losing launch buttons.
- **`← MAP` pill**, top-left, on every non-hub screen — one consistent way out.
- **Mid-play exit is a small `✕`** that drops to song-select (not all the way to map)
  — cheap recovery from a mis-tap.
- **Driver song→difficulty:** tap song → difficulty pills expand in place → tap to play.
  Medium/Hard unlock **per song** (earn the grade on the tier below). Locked pills show
  the exact requirement inline.
- **Silent-first:** nothing depends on audio; fully playable muted.

## To wire into the real games
- Per-song difficulty unlocks are a `save.js` change — song records need
  `{ easy:{grade}, medium:{grade}, hard:{grade|null} }` instead of one global toggle.
- Replace the `[MOCK]` play screen with each real canvas; keep the `✕` → song-select
  and the result → `← MAP` contract identical across modes.
